module Settings exposing (..)

settings = { server = "http://srv2.dev.faifly.com:8080" }
