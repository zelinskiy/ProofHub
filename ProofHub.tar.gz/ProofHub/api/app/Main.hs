module Main where

import App

main :: IO ()
main = startApp
